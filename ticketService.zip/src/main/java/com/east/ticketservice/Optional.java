package com.east.ticketservice;


/**
 * Literal class to meet the ITicketService 
 *
 * @param <T>
 */
public interface Optional<T>{

	public T get() ;

	public void set(T t);

	
}
