package com.east.ticketservice;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;



public class SeatHold {
	int seatHoldId; // uniquie id for this

	String customerEmail;
	long holdTime;
	Set<Seat>seats;
	String reason;
	int desiredSeats=0;
	
	public static long DEFAULTHOLDTIME=20000;// milliseconds
	String id; // to id this performance
	
	public static  transient int idGen=0;// hardcoded for now
	public SeatHold(){
		super();
		// this is a uniqueness thing, hardcoded for now
		this.seatHoldId=idGen++;
		holdTime= System.currentTimeMillis()+DEFAULTHOLDTIME;
		seats = new HashSet<Seat>();

	}
	
	public SeatHold(int numSeats, String id){
		this();
		this.desiredSeats=numSeats;
		this.id=id;  // id of the performance in the TicketService
	}
	

	public boolean isValid(){
		// desiredSeats used to determine if SeatHold is full/complete
		return seats!=null && !seats.isEmpty() && this.seats.size()==desiredSeats;
	}
	
	public boolean add(Seat seat) {
		return seats.add(seat);
	}

	public boolean  add(List<Seat> held) {
		return seats.addAll(held);
	}
	
	
	/**
	 * Return a list of all Seats in a level helper method.
	 * @return
	 */
	public Map<Integer, List<Seat>> bySectionSeats() {
		Map<Integer, List<Seat>>map= new HashMap<Integer,List<Seat>>();
		Iterator<Seat>iter = this.getSeats().iterator();
		while(iter.hasNext()){
			Seat s = iter.next();
			List<Seat>list = map.get(s.getLevel());
			if(list==null){
				list = new ArrayList<Seat>();
				map.put(s.getLevel(), list);
			}
			list.add(s);
			
		}
		return map;
	}
	
	
	@Override
	public String toString(){
		StringBuilder sb = new StringBuilder();
		sb.append(idGen);
		if(isValid()) sb.append(" number: "+seats.size());
		else sb.append(" empty");
		sb.append(" holdTime="+holdTime);
		if(reason!=null)sb.append(reason);
		return sb.toString();
	}
	
	public int getDesiredSeats() {
		return desiredSeats;
	}

	public void setDesiredSeats(int desiredSeats) {
		this.desiredSeats = desiredSeats;
	}

	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}


	public int getSeatHoldId() {
		return seatHoldId;
	}

	public void setSeatHoldId(int seatHoldId) {
		this.seatHoldId = seatHoldId;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public Set<Seat> getSeats() {
		return seats;
	}

	public void setSeats(Set<Seat> seats) {
		this.seats = seats;
	}
	
	public long getHoldTime(){
		return this.holdTime;
	}

	/**
	 * for the performance
	 * @return
	 */
	public String getId() {
		return id;
	}



	
}
