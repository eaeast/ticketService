package com.east.ticketservice;


import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;


@Service
@Scope("prototype")
public class TicketService implements ITicketService{
	final Logger log = LoggerFactory.getLogger(TicketService.class);
	

	String  id;// to identify this TicketService uniquely
	
	@Autowired
	ISeats ss;
	                                  
	@Autowired
	ISeatHolds shc; ; // this is a helper to lookup the SeatHold objects 
	                                   // Integer is the SeatHoldId
	
	public TicketService(){
	}
	public TicketService(String id){
		this();
		this.id=id;
	}
	
	/**
	 * Just did this quick ..
	 * @param id
	 * @return
	 */
	public TicketService forCamel(String id){
		this.setId(id);
		return this;
	}
	
	public ISeats getSeatsService() {
		return ss;
	}
	public void setSeatsService(ISeats ss) {
		this.ss = ss;
	}
	public ISeatHolds getSeatHoldService() {
		return shc;
	}
	public void setShc(ISeatHolds shc) {
		this.shc = shc;
	}
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int numSeatsAvailable(){
		return numSeatsAvailable(null);
	}
	public int numSeatsAvailable(Optional<Integer> opt){

			if(opt==null){
				List<ISectionSeats>iss = this.getSeatsService().getAllSectionSeats(id);
				if(iss==null){
					// TODO erroe
					log.warn("No ISectionSeats found in the SeatsService");
					return 0;
				}
				int sum = 0;
				Iterator<ISectionSeats>iter = iss.iterator();
				while(iter.hasNext()){
					sum+=iter.next().getNumSeatsAvailable();
				}
				return sum;
			}
			else{
				ISectionSeats iss = this.getSeatsService().getSectionSeats(id, opt.get());
				if(iss==null){
					// TODO erroe
					log.warn("No ISectionSeats found in for level "+opt.get());
					return 0;
				}
				return iss.getNumSeatsAvailable();
			}
	}
	

	

	public SeatHold findAndHoldSeats(int numSeats, Optional<Integer> minLevel,
			Optional<Integer> maxLevel, String customerEmail){

		SeatHold sh =   new SeatHold(numSeats, this.getId()); // has a isValid() method
		sh.setCustomerEmail(customerEmail);
		if(numSeats<=0){
			sh.setReason(numSeats+" <=0");
			return sh; // error reason/etc not added
		}
		
		// return if number of seats not available
		int left = numSeatsAvailable(null);
		if(numSeats >left ){
			sh.setReason("Not enough seats: "+numSeats+" > " + left);
			return sh; 
		}

		int curLevel =1; // assume 1, could be min of seatCollection.keys
		if(minLevel!=null){
			// start here;
			// continue till numSeats done
			// go to maxLevel
			curLevel = minLevel.get();
		}

		
		int numToHold=numSeats;		
//////////
// this changes the database
//////////
		while(numToHold>0 ){
			// no more levels so will have return the seats if any
			if(maxLevel!=null && curLevel>maxLevel.get())
				break;
			
			ISectionSeats ss = this.getSeatsService().getSectionSeats(id, curLevel);

			if(ss==null)break;// no more levels to search so will have to return seats ...
			
			////////////////////
			// send to SectionSeats
			List<Seat> held = ss.findAndHoldSeats(numToHold, sh.getHoldTime());
			if(held.isEmpty()){
				continue;
			}
			numToHold-=held.size();
			sh.add(held);
			curLevel++;
		}
///////////////
// need to rollback if change not correct 
// need to catch exception and rollback 
//////////////
		if(!sh.isValid()){
			// need to release the seats back
			// release to the correct SectionSeats ...
			Map<Integer, List<Seat>> map = sh.bySectionSeats();
			Iterator<Integer>iter = map.keySet().iterator();
			while(iter.hasNext()){
				Integer level = iter.next();
				ISectionSeats ss = this.getSeatsService().getSectionSeats(id, curLevel);
				ss.free(map.get(level), sh.getHoldTime());
			}
			sh.setReason("not enough seats.  Rolled back.");
			return sh;
		}
		
////////////////////
// persist the seatHold
////////////////////
this.shc.saveSeatHold(sh);
		return sh;
	}
	
	
	
	public synchronized String reserveSeats(int seatHoldId, String customerEmail){

		SeatHold sh = this.shc.getSeatHold(seatHoldId);
		
	    if(sh==null || sh.getSeats()==null || sh.getSeats().isEmpty() ){
	    	 return "No seatHolds found for "+customerEmail;
	    }
	    
	    // reserve only if time to large, otherwise free
	    if(sh.getHoldTime()>System.currentTimeMillis()){
	    	// do not reserve ...
	    	// put back to free 
	    }
	    
	    int toReserve = sh.getSeats().size();// all seats
	    int reserved =0;
	    Map<Integer, List<Seat>> map = sh.bySectionSeats();
		Iterator<Integer>iter = map.keySet().iterator();
		//TODO: need to add in for one section failure ...
		// need to unreserve
		while(iter.hasNext()){
			Integer level = iter.next();
			ISectionSeats iss = this.getSeatsService().getSectionSeats(id, level);
			List<Seat>list = map.get(level);
			if(iss.reserve(list, sh.getHoldTime()))
			  reserved+=list.size();
			else{
				log.warn("Failed to reserve seats for level "+level);
				return "error";
			}
		}
		
		return "Reserved "+reserved;

	}

	@Override
	public boolean isFree(int level, int row, int seat) {
		return this.getSeatsService().getSectionSeats(id, level).isFree(row, seat);
	}

	@Override
	public boolean isHold(int level, int row, int seat) {
		return this.getSeatsService().getSectionSeats(id, level).isHold(row, seat);
	}

	@Override
	public boolean isReserved(int level, int row, int seat) {
		return this.getSeatsService().getSectionSeats(id, level).isReserved(row, seat);
	}





}
