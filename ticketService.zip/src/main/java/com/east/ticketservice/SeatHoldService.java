package com.east.ticketservice;

import java.util.HashMap;
import java.util.Map;

public class SeatHoldService implements ISeatHolds{

	Map<Integer, SeatHold> seatHolds;
	
	public SeatHoldService(){
		seatHolds=new HashMap<Integer, SeatHold>();
		
	}
	@Override
	public boolean saveSeatHold(SeatHold sh) {
		// save to db
		return seatHolds.put(sh.getSeatHoldId(), sh)!=null;
	}

	@Override
	public SeatHold getSeatHold(Integer id) {
		// read from db
		return seatHolds.get(id);
	}

}
