package com.east.ticketservice;

import java.util.List;


public interface ISeats {

	public ISectionSeats getSectionSeats(String id, int level);

	public List<ISectionSeats> getAllSectionSeats(String id) ;
}
