package com.east.ticketservice;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * Venue defined the seats available by a Venue Level.
 * 
 * Every Event will have its own Venue.
 *
 */
public class Venue {
	String name;
	
	Map<Integer, VenueLevel>venueLevels;
	
	
	public Venue(){
		venueLevels=new HashMap<Integer,VenueLevel>();

	}
	public Venue(String name){
		this();
		this.name=name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
    public void addVenueLevel(VenueLevel vl){
    	venueLevels.put(vl.getId(), vl);
    }
	protected Collection<VenueLevel> getVenueLevels() {
		return venueLevels.values();
	}
	
	public VenueLevel get(Integer level){
		return this.venueLevels.get(level);
	}
	public VenueLevel getVenueLevel(Integer level){
		return this.venueLevels.get(level);
	}


}
