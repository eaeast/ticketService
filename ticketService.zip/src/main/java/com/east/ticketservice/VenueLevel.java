package com.east.ticketservice;



public class VenueLevel {
	String name;
	Integer id; // levelId
	
	double price;
	int rows;
	int numSeats;
	
	
	/**
	 * Constructor for a Venues.
	 * 
	 * Assumes all seats/rows same price.
	 * Assumes all rows have same number of seats
	 * 
	 * This can becomes a builder pattern to create difference Levels with
	 * different seats.
	 * 
	 */
	public VenueLevel(String name, int levelId, double price, int rows, int seats){
		// check for nulls, skipping for now
		this.name=name;
		this.id=levelId;
		this.price=price;
		this.rows=rows;
		this.numSeats=seats;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public double getPrice() {
		return price;
	}


	public void setPrice(double price) {
		this.price = price;
	}


	public int getRows() {
		return rows;
	}


	public void setRows(int rows) {
		this.rows = rows;
	}


	public int getNumSeats() {
		return numSeats;
	}


	public void setNumSeats(int numSeats) {
		this.numSeats = numSeats;
	}
	

}
