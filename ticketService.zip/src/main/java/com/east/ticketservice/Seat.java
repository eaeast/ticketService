package com.east.ticketservice;

public class Seat {
	
	Integer level; // venue level
	Integer row;   // row 
	Integer number; // seat in row
	Double price;
	
	
	public Seat(int level, int row, int seatNumber, double price){
		this.level=level;
		this.row=row;
		this.number=seatNumber;
		this.price=price;
	}

	// for testing
    public String toString(){
    	return "seat:"+level+" "+row+" "+number;
    }
	public Integer getLevel() {
		return level;
	}


	public void setLevel(Integer level) {
		this.level = level;
	}


	public Integer getRow() {
		return row;
	}


	public void setRow(Integer row) {
		this.row = row;
	}


	public Integer getNumber() {
		return number;
	}


	public void setNumber(Integer number) {
		this.number = number;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}



	
}
