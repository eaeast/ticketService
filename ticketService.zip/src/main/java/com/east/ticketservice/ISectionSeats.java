package com.east.ticketservice;

import java.util.List;

public interface ISectionSeats {

	
	public Integer getSection();
	public String getId(); 
	
	public int getNumSeatsAvailable() ;
	public List<Seat> findAndHoldSeats( int numToHold, Long holdTill);
	public boolean free( List<Seat> seats, Long holdTill) ;
	public boolean reserve(List<Seat> seats, Long holdTill) ;
	
	public boolean isReserved( int row, int seat);
	public boolean isHold( int row, int seat);
	public boolean isFree( int row, int seat);

}
