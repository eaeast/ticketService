package com.east.ticketservice;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * id and section are unique.
 *  *
 */
public class SectionSeats implements ISectionSeats{
	final Logger log = LoggerFactory.getLogger(SectionSeats.class);
	public static long RESERVED=1L;
	public static long FREE=0L;
	
	Integer section;
	String id; 
	int rows;
	int numSeats;
	double price;
	Long[][] seats;  //[row-1][seat-1]= 0 1   otherwise the hold System.millis 
	                 // 

	public SectionSeats(){
		super();
	}
	
	@Override


	public String toString(){
		return id+" "+getNumSeatsAvailable() ;
	}
	
	public SectionSeats(String id, Integer section, int rows, int numSeats, 
			double price,Long[][] seats ){
		this();
		this.id=id;
		this.rows=rows;
		this.section=section;
		this.numSeats=numSeats;
		this.price=price;
		this.seats = seats;
	}
	
	public SectionSeats(String id, Integer section, int rows, int numSeats, double price ){
		this();
		this.id=id;
		this.rows=rows;
		this.section=section;
		this.numSeats=numSeats;
		this.price=price;
		this.seats = new Long[rows][numSeats];

		for(int i=0;i<rows;i++){
			for(int j=0;j<numSeats;j++){
				seats[i][j]=FREE;  
			}
		}
	}
	

	public synchronized int getNumSeatsAvailable() {
		int num =0;
        for (int row = 0; row < rows; row++) {
        	for(int snum=0;snum<numSeats;snum++){
        		if(seats[row][snum]==FREE){  
        			num+=1;
        		}
        		
        	}
        }
        return num;
	}

	
	public synchronized List<Seat> findAndHoldSeats(int numToHold, Long holdTill) {
		// 
		// just find and fill first ones found
		// add to SeatHold ..
		// no matter where/etc
		// return 
        List<Seat> sa = new ArrayList<Seat>();
        
        for (int row = 0; row < this.getRows(); row++) {
        	for(int snum=0;snum<this.getNumSeats();snum++){
        		if(seats[row][snum]==FREE){
        			log.info("holding "+this.getId()+" "+ (row+1) + " "+ (snum+1));
        			sa.add(new Seat(this.getSection(), row+1, snum+1,this.getPrice()));
        			seats[row][snum]=holdTill;
        			
        			if(sa.size()==numToHold)
        				return sa;
        		}
        		
        	}
        }
        return sa;
	}


	public boolean free(List<Seat> seatList, Long holdTill) {
		Iterator<Seat> iter = seatList.iterator();
		// ensure all correct
		// if ok, then change
		while(iter.hasNext()){
			Seat s = iter.next();
			if(s.getLevel()!=section)continue;// only seats on this level ...
			if(holdTill!=null && seats[s.getRow()-1][s.getNumber()-1]!=holdTill.longValue()){
				// ERROR TODO:  SeatHold is not correct
				return false;
			}
		}
		iter = seatList.iterator();
		// ensure all correct
		// if ok, then change
		while(iter.hasNext()){
			Seat s = iter.next();
			if(s.getLevel()!=section)continue;// only seats on this level ...
			log.info("freeing "+s.getLevel()+" "+ s.getRow() + " "+ s.getNumber());

			seats[s.getRow()-1][s.getNumber()-1]=FREE;
		}
		return true;
	}
	
	
	public synchronized boolean reserve(List<Seat> seatList, Long holdTill) {
		Iterator<Seat> iter = seatList.iterator();
		// ensure all correct
		// if ok, then change
		while(iter.hasNext()){
			Seat s = iter.next();
			if(s.getLevel()!=this.getSection())continue;// only seats on this level ...
			if(seats[s.getRow()-1][s.getNumber()-1]!=holdTill.longValue()){
				// ERROR TODO:  SeatHold is not correct
				log.warn("Seat: "+ ",  "+seats[s.getRow()-1][s.getNumber()-1]+ " != "+holdTill);
				return false;
			}
		}
		iter = seatList.iterator();
		// ensure all correct
		// if ok, then change
		while(iter.hasNext()){
			Seat s = iter.next();
			if(s.getLevel()!=this.getSection())continue;// only seats on this level ...
			log.info("reserving "+s.getLevel()+" "+ s.getRow() + " "+ s.getNumber()+ " "+ s.getPrice());
			seats[s.getRow()-1][s.getNumber()-1]=RESERVED;
		}
		return true;
	}
	/**
	 * Helpers for testing
	 * @param level
	 * @param row
	 * @param seat
	 * @return
	 */
	public synchronized boolean isFree(int row, int seat) {
		// 
		// lock if not class syncrhonized
		try{
			return seats[row-1][seat-1]==FREE;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return false;
	}

	public synchronized boolean isReserved( int row, int seat) {

		try{
			return seats[row-1][seat-1]==RESERVED;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return false;
	}
	public synchronized boolean isHold(int row, int seat) {
		try{
			return seats[row-1][seat-1]!=FREE && seats[row-1][seat-1]!=RESERVED;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return false;
	}
	public int getRows() {
		return rows;
	}

	public void setRows(int rows) {
		this.rows = rows;
	}

	public int getNumSeats() {
		return numSeats;
	}

	public void setNumSeats(int numSeats) {
		this.numSeats = numSeats;
	}
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Integer getSection() {
		return section;
	}

	public void setSection(Integer section) {
		this.section = section;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}


	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((section == null) ? 0 : section.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SectionSeats other = (SectionSeats) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (section == null) {
			if (other.section != null)
				return false;
		} else if (!section.equals(other.section))
			return false;
		return true;
	}
}
