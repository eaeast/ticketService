package com.east.ticketservice;

public interface ISeatHolds {

	public boolean saveSeatHold(SeatHold sh);
	public SeatHold getSeatHold(Integer id);
}
