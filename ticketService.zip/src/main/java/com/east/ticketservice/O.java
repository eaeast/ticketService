package com.east.ticketservice;

/**
 * To meet the ITicketService contract
 *
 */
public class O implements Optional<Integer>{

	Integer i;
	
	public O(){
		super();
	}
	public O(int i){
		this.i=i;
	}
	@Override
	public Integer get() {
		return i;
	}

	@Override
	public void set(Integer t) {
		this.i=t;
	}
}
