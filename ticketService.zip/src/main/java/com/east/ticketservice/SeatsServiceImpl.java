package com.east.ticketservice;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

public class SeatsServiceImpl implements ISeats{
	
	Map<Integer, ISectionSeats>seatCollection;
    // Integer is the section number
    // the Long[][] must be persisted in some fashion
    // the value of the Long[][]= 0, 1, or Expiration time
    // setting these 
    // This class also has helper collections for speed
    // to limit searches ...
	

	
	public SeatsServiceImpl(){
		seatCollection=new HashMap<Integer,ISectionSeats>();
	}

	
	public boolean setSeats(Collection<ISectionSeats>seats){
		Iterator<ISectionSeats> iter = seats.iterator();
		while(iter.hasNext()){
			ISectionSeats iss = iter.next();
			seatCollection.put(iss.getSection(), iss);
		}
		return true;
	}

	@Override
	public ISectionSeats getSectionSeats(String id, int level) {
		// can do a look up here 
		// for now, just use impl
		// or return another impl
		return seatCollection.get(level);
	}


	@Override
	public List<ISectionSeats> getAllSectionSeats(String id) {
		// do a look up here 
		// for now, just use
		// or return another impl
		Iterator<Integer> iter = new TreeSet<Integer>(seatCollection.keySet()).iterator();
		ArrayList<ISectionSeats>iss =new ArrayList<ISectionSeats>();
	    while(iter.hasNext())iss.add(seatCollection.get(iter.next()));
	    return iss;
	}
}
