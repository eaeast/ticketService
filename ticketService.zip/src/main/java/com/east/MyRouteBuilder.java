package com.east;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.spring.Main;

import com.east.ticketservice.TicketService;

public class MyRouteBuilder 
	extends RouteBuilder {

	    /**
	     * Allow this route to be run as an application
	     */
	    public static void main(String[] args) throws Exception {
	        new Main().run(args);
	    }

	    public void configure() {
	        // populate the message queue with some messages

	        from("jetty:http://0.0.0.0/test?sessionSupport=false").
	        log("received message for performance ${header.performance}" ).
	        bean(TicketService.class, "forCamel(${body})");
	 
	        from("jetty:http://0.0.0.0/numSeats?sessionSupport=false").
	        log("received message for performance ${header.performance}" );
	        
	    }

}
