package com.east.ticketservice;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class TicketServiceTest 
{

    @Test
    public void numberAvailable()
    {

    	Venue v = buildVenue();
    	TicketService ts = buildTicketService(v, "testPerformance" );
    	
    	Assert.assertEquals(ts.numSeatsAvailable(null), 6250);
//    	1250
//    	2000
//    	1500
//    	1500
//    	6250 total

    }
    
    @Test
    public void holdFirst()
    {
    	Venue v = buildVenue();

    	TicketService ts = buildTicketService(v, "testPerformance" );
    	SeatHold sh = ts.findAndHoldSeats(1, null, null, "eaeast@yahoo.com");
    	Assert.assertEquals(sh.getSeats().size(), 1);
    	Assert.assertEquals(ts.numSeatsAvailable(null), 6249);
    	Assert.assertEquals(ts.numSeatsAvailable(new O(1)), 1249);
    	Assert.assertEquals(ts.numSeatsAvailable(new O(2)), 2000);
    	Assert.assertEquals(ts.numSeatsAvailable(new O(3)), 1500);
    	Assert.assertEquals(ts.numSeatsAvailable(new O(4)), 1500);

    	Assert.assertTrue(ts.isHold(1, 1, 1));
    	Assert.assertTrue(ts.isFree(1, 1, 2));
    }
    @Test
    public void holdFirstInSection2()
    {
    	Venue v = buildVenue();
    	TicketService ts = buildTicketService(v, "testPerformance" );
        SeatHold sh = ts.findAndHoldSeats(1, new O(2), new O(2), "eaeast@yahoo.com");
        Assert.assertEquals(sh.getSeats().size(), 1);
        Assert.assertEquals(ts.numSeatsAvailable(null), 6249);
        Assert.assertEquals(ts.numSeatsAvailable(new O(1)), 1250);
        Assert.assertEquals(ts.numSeatsAvailable(new O(2)), 1999);
        Assert.assertEquals(ts.numSeatsAvailable(new O(3)), 1500);
        Assert.assertEquals(ts.numSeatsAvailable(new O(4)), 1500);
    }
    
    @Test
    public void holdAcrossSection1andSection2()
    {
//    	1250
//    	2000
//    	1500
//    	1500
//    	6250 total
    	Venue v = buildVenue();
    	TicketService ts = buildTicketService(v, "testPerformance" );
        SeatHold sh = ts.findAndHoldSeats(2250, new O(1), new O(2), "eaeast@yahoo.com");
        Assert.assertEquals(sh.getSeats().size(), 2250);
        Assert.assertEquals(ts.numSeatsAvailable(null), 4000);
        Assert.assertEquals(ts.numSeatsAvailable(new O(1)), 0);
        Assert.assertEquals(ts.numSeatsAvailable(new O(2)), 1000);
        Assert.assertEquals(ts.numSeatsAvailable(new O(3)), 1500);
        Assert.assertEquals(ts.numSeatsAvailable(new O(4)), 1500);
    }
//    @Test
    public void holdTooManyInSection()
    {
//    	1250
//    	2000
//    	1500
//    	1500
//    	6250 total
    	Venue v = buildVenue();
    	TicketService ts = buildTicketService(v, "testPerformance" );
        SeatHold sh = ts.findAndHoldSeats(2250, new O(2), new O(2), "eaeast@yahoo.com");
        Assert.assertTrue(!sh.isValid());
        Assert.assertEquals(ts.numSeatsAvailable(null), 6250);
        Assert.assertEquals(ts.numSeatsAvailable(new O(1)),1250);
        Assert.assertEquals(ts.numSeatsAvailable(new O(2)), 2000);
        Assert.assertEquals(ts.numSeatsAvailable(new O(3)), 1500);
        Assert.assertEquals(ts.numSeatsAvailable(new O(4)), 1500);
    }
//
//    
    @Test
    public void buy()
    {
//    	1250
//    	2000
//    	1500
//    	1500
//    	6250 total
    	Venue v = buildVenue();
    	TicketService ts = buildTicketService(v, "testPerformance" );
        SeatHold sh = ts.findAndHoldSeats(1, new O(2), new O(2), "eaeast@yahoo.com");
        Assert.assertTrue(sh.isValid());
        Assert.assertEquals(ts.numSeatsAvailable(null), 6249);
        Assert.assertEquals(ts.numSeatsAvailable(new O(1)),1250);
        Assert.assertEquals(ts.numSeatsAvailable(new O(2)), 1999);
        Assert.assertEquals(ts.numSeatsAvailable(new O(3)), 1500);
        Assert.assertEquals(ts.numSeatsAvailable(new O(4)), 1500);
        
        Assert.assertTrue(ts.isHold(2, 1, 1));// for testing

        ts.reserveSeats(sh.getSeatHoldId(), sh.getCustomerEmail());
        
        Assert.assertTrue(ts.isReserved(2, 1, 1));// for testing

        Assert.assertEquals(ts.numSeatsAvailable(null), 6249);

    }
    @Test
    public void testVenueConstructor()
    {

    	Venue v = buildVenue();
    	
    	Assert.assertTrue( "testVenue".equals(v.getName()) );
    	Assert.assertTrue(v.get(1).getNumSeats()==50);
    	Assert.assertTrue(v.get(1).getRows()==25);
    }
    
    public Venue buildVenue(){
        VenueLevel v1 = new VenueLevel(
        		"Orchestra", 1, 100.00D, 25, 50);
        VenueLevel v2 = new VenueLevel(
        		"Main", 2, 75.00D, 20, 100);
        VenueLevel v3 = new VenueLevel(
        		"Balcony 1", 3, 50.00D, 15, 100);
        VenueLevel v4 = new VenueLevel(
        		"Balcony 2", 4, 40.00D, 15, 100);
        
        Venue v = new Venue("testVenue");
        v.addVenueLevel(v1);
        v.addVenueLevel(v2);
        v.addVenueLevel(v3);
        v.addVenueLevel(v4);

        
        return v;
    }
    public TicketService buildTicketService(Venue v, String performance){
    	TicketService ts = new TicketService();
    
    	ts.setId(performance);
    	SeatsServiceImpl ssi = new SeatsServiceImpl();

    	List<ISectionSeats>list=new ArrayList<ISectionSeats>();
    	Iterator<VenueLevel>iter = v.getVenueLevels().iterator();
    	while(iter.hasNext()){
    		VenueLevel vl = iter.next();
    		SectionSeats ss = new SectionSeats(performance, vl.getId(), 
    				vl.getRows(),
    				vl.getNumSeats(), 
    				vl.getPrice());
    		list.add(ss);
    	}
    	ssi.setSeats(list);
    	ts.setSeatsService(ssi);
    	
    	ts.setShc(new SeatHoldService());
    	return ts;
    }
}
